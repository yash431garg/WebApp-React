import React from "react";

const TableRowElement = (props) => {
  const { item } = props;
  
  return <tr></tr>;
};
export default TableRowElement;
