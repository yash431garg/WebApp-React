export const COLUMNS = [
  {
    id:"invoiceName",
    Header: "Invoice Name",
    accessor: "invoiceName"
  },
  // {
  //   id:"invoiceDate",
  //   Header: "Creation Date",
  //   accessor: "invoiceDate"
  // }
];