import React from 'react'

//this page is shown when url match not found
function NotFound() {
    return (
        <h3 >Not Found! 404</h3>
    )
}

export default NotFound
